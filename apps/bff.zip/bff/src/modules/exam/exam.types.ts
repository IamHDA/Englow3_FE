// Exam-domain enums. Deliberately not shared with the user/onboarding domain:
// the backend keeps com.englow3.exam.entity.CertificateType separate from
// com.englow3.user.entity.CertificateType because there the value is a
// learner's goal, here it is one half of what identifies a paper.
// DRAFT -> PENDING_REVIEW -> PUBLISHED, with REJECTED as the way back.
export type ExamStatus =
  "DRAFT" | "PENDING_REVIEW" | "REJECTED" | "PUBLISHED" | "ARCHIVED";
export type ExamType = "PLACEMENT" | "MOCK";
export type CertificateType = "IELTS" | "TOEIC";
export type CertificateVariant = "LR" | "SW" | "ACADEMIC" | "GENERAL";
export type TargetLevel = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";

// mirrors GET /api/admin/exams exactly as the backend returns it
export type ExamListItemResponse = {
  id: string;
  title: string;
  examType: ExamType;
  // null on a paper with no certificate (e.g. a PLACEMENT exam) - the
  // backend's own Exam.requireCoherentCertificate allows that combination.
  certificateType: CertificateType | null;
  certificateVariant: CertificateVariant | null;
  targetLevel: TargetLevel | null;
  status: ExamStatus;
  versionNumber: number;
  createdByUserId: string;
  publishedAt: string | null; // ISO-8601 instant, null until published
  createdAt: string; // ISO-8601 instant
  submittedForReviewAt: string | null;
  // Why the paper came back. On the list because that is where its author reads it.
  reviewNote: string | null;
};

// mirrors ExamResponse (POST create/publish/archive, PUT update) exactly as the backend returns it
export type ExamResponse = {
  id: string;
  title: string;
  description: string;
  examType: ExamType;
  certificateType: CertificateType | null;
  certificateVariant: CertificateVariant | null;
  targetLevel: TargetLevel | null;
  durationSeconds: number;
  maxRawScore: number;
  passScore: number | null;
  status: ExamStatus;
  versionNumber: number;
  createdByUserId: string;
  publishedAt: string | null; // ISO-8601 instant, null until published
  submittedForReviewAt: string | null;
  reviewedByUserId: string | null;
  reviewedAt: string | null;
  reviewNote: string | null;
};

// mirrors com.englow3.shared.page.PageResponse exactly as the backend returns it
export type ExamPageResponse = {
  items: ExamListItemResponse[];
  page: number;
  size: number;
  totalItems: number;
  totalPages: number;
};

/** Every filter is optional - an absent one is not a filter, matching SearchExamRequest. */
export type SearchExamsParams = {
  status?: ExamStatus;
  examType?: ExamType;
  title?: string;
  page?: number;
  size?: number;
};

// mirrors LearnerExamCardResponse from GET /api/exams
export type LearnerExamItemResponse = {
  id: string;
  title: string;
  description: string;
  examType: ExamType;
  certificateType: CertificateType | null;
  certificateVariant: CertificateVariant | null;
  targetLevel: TargetLevel | null;
  durationSeconds: number;
  maxRawScore: number;
  passScore: number | null;
  questionCount: number;
  status: ExamStatus;
  publishedAt: string | null;
  /** Per learner. Null until they have finished a sitting. */
  bestScorePercentage: number | null;
  attemptStatus: "NOT_STARTED" | "IN_PROGRESS" | "COMPLETED";
};

export type LearnerExamPageResponse = {
  items: LearnerExamItemResponse[];
  page: number;
  size: number;
  totalItems: number;
  totalPages: number;
};

export type SearchLearnerExamsParams = {
  examType?: ExamType;
  certificateType?: CertificateType;
  certificateVariant?: CertificateVariant;
  targetLevel?: TargetLevel;
  title?: string;
  page?: number;
  size?: number;
};

// The paper the learner sits, from GET /api/exam-attempts/{attemptId}/paper.
// It deliberately carries no `correct` flag and no explanation: the backend
// strips both so the answer key never reaches the browser mid-attempt. They
// come back afterwards on the attempt result instead.
export type QuestionOptionDto = {
  id: string;
  content: string;
  orderNo: number;
};

export type QuestionDto = {
  id: string;
  questionType: string;
  content: string;
  difficultyLevel: string;
  skillType: string;
  questionCategory: string | null;
  orderNo: number;
  maxRawScore: number;
  options: QuestionOptionDto[];
};

// The backend resolves object keys into pre-signed URLs before answering, so
// what arrives here is already fetchable and expires on its own.
export type QuestionSetDto = {
  id: string;
  title: string | null;
  instruction: string | null;
  orderNo: number;
  content: string | null;
  audioUrl: string | null;
  imageUrl: string | null;
  questions: QuestionDto[];
};

export type SectionPartDto = {
  id: string;
  orderNo: number;
  title: string;
  instruction: string | null;
  content: string | null;
  audioUrl: string | null;
  imageUrl: string | null;
  questionSets: QuestionSetDto[];
};

export type ExamSectionDto = {
  id: string;
  sectionType: string;
  orderNo: number;
  maxRawScore: number;
  scoredByCriteria: boolean;
  timeLimitSeconds: number | null;
  parts: SectionPartDto[];
};

export type ExamPaperResponse = {
  id: string;
  title: string;
  description: string;
  examType: ExamType;
  certificateType: CertificateType | null;
  certificateVariant: CertificateVariant | null;
  targetLevel: TargetLevel | null;
  durationSeconds: number;
  maxRawScore: number;
  passScore: number | null;
  versionNumber: number;
  sections: ExamSectionDto[];
};

export type ExamAttemptStatus = "IN_PROGRESS" | "SCORED" | "EXPIRED";

export type AttemptOptionReviewDto = {
  optionId: string;
  correct: boolean;
  explanation: string | null;
};

export type AttemptQuestionReviewDto = {
  questionId: string;
  selectedOptionIds: string[];
  correctOptionIds: string[];
  correct: boolean;
  awardedRawScore: number;
  explanation: string | null;
  options: AttemptOptionReviewDto[];
};

// mirrors ExamAttemptResponse - the shape POST /api/exams/{id}/attempts,
// POST /api/exam-attempts/{id}/submit and GET /api/exam-attempts/{id}/result
// all answer with. The scoring fields stay null while the attempt is
// IN_PROGRESS, and `questions` is empty until it is scored.
export type ExamAttemptResponse = {
  id: string;
  examId: string;
  status: ExamAttemptStatus;
  startedAt: string; // ISO-8601 instant
  expiresAt: string; // ISO-8601 instant - the deadline the UI counts down to
  submittedAt: string | null;
  scoredAt: string | null;
  rawScore: number | null;
  maxRawScore: number | null;
  scorePercentage: number | null;
  correctAnswerCount: number | null;
  questionCount: number;
  /** True when the backend handed back an attempt that was already open. */
  resumed: boolean;
  /** Null except on a history row - a sitting knows its own paper's name. */
  examTitle: string | null;
  questions: AttemptQuestionReviewDto[];
};

export type ExamAttemptPageResponse = {
  items: ExamAttemptResponse[];
  page: number;
  size: number;
  totalItems: number;
  totalPages: number;
};

// mirrors POST /api/exam-attempts/{id}/submit request body
export type SubmitExamAttemptRequest = {
  answers: SubmittedAnswer[];
};

export type SubmittedAnswer = {
  questionId: string;
  selectedOptionIds: string[];
};
